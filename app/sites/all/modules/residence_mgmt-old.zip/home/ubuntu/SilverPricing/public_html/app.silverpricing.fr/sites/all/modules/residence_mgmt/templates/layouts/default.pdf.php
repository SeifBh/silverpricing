<?php

use mikehaertl\wkhtmlto\Pdf;
use mikehaertl\tmp\File;

?>

<?php ob_start(); ?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
        <style type="text/css">

            body {
                font-family: "Times New Roman", Georgia, Serif;
            }

            #header table.table {
                width: 100%;
                font-size: 12px;
                text-align: center;
                border-collapse: collapse;
            }

            #header table.table td {
                border: 1px solid #000;
            }

        </style>
    </head>
    <body>
        <div id="header">
            <table class="table">
                <tr>
                    <td colspan="2" style="padding: 5px 5px;">
                        <img src="<?php echo BASE_URL; ?>/sites/all/modules/residence_mgmt/assets/img/logo-silverpricing.png" alt="Silverpricing"/>
                    </td>
                </tr>

                <tr>
                    <td>
                        <span><?php echo "Date de création"; ?></span><br />
                        <?php echo date( "d-m-Y H:i:s", $history->created); ?>
                    </td>

                    <td>
                        <span><?php echo 'Utilisateur'; ?></span><br />
                        <?php echo $account->field_firstname . " " . $account->field_lastname; ?>
                    </td>
                </tr>
            </table>
        </div>
    </body>
</html>

<?php $header = ob_get_clean(); ?>


<?php ob_start(); ?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />

        <script>
            function subst() {
                var vars = {};
                var query_strings_from_url = document.location.search.substring(1).split('&');
                for (var query_string in query_strings_from_url) {
                    if (query_strings_from_url.hasOwnProperty(query_string)) {
                        var temp_var = query_strings_from_url[query_string].split('=', 2);
                        vars[temp_var[0]] = decodeURI(temp_var[1]);
                    }
                }
                var css_selector_classes = ['page', 'frompage', 'topage', 'webpage', 'section', 'subsection', 'date', 'isodate', 'time', 'title', 'doctitle', 'sitepage', 'sitepages'];
                for (var css_class in css_selector_classes) {
                    if (css_selector_classes.hasOwnProperty(css_class)) {
                        var element = document.getElementsByClassName(css_selector_classes[css_class]);
                        for (var j = 0; j < element.length; ++j) {
                            element[j].textContent = vars[css_selector_classes[css_class]];
                        }
                    }
                }
            }
        </script>
        <style type="text/css">
            body {
                font-family: "Times New Roman", Georgia, Serif;
            }

            #footer {
                padding-bottom: 50px;
            }

            #footer table {
                width: 100%;
                font-size: 12px;
            }
        </style>
    </head>
    <body onload="subst()">
        <div id="footer">
            <div style="border-top: 1px solid #000;">
                <table>
                    <tr>
                        <td><?php echo "Crée le" . ' : '. date('Y-m-d H:i:s'); ?></td>
                        <td><?php echo 'Page'; ?> <span class="page"></span> / <span class="topage"></span></td>
                    </tr>
                </table>
            </div>
        </div>
    </body>
</html>
<?php $footer = ob_get_clean(); ?>

<?php

$option = array(
  'binary' => RESIDENCE_MGMT_WKHTMLTOPDF,
  'page-size' => 'A4',
  'header-html' => $header,
  'header-spacing' => '5',
  'footer-html' => $footer,
  'footer-spacing' => '10',
  'ignoreWarnings' => true,
  'commandOptions' => array(
        'useExec' => true,
        'procEnv' => array(
            'LANG' => 'en_US.utf-8',
        ),
    ),
  'javascript-delay' => 1000
);

$pdf = new Pdf($option);
$pdf->addPage($content);

if (!$pdf->send($generatedFile . ".pdf")) {
    $error = $pdf->getError();

    varDebug($error);
}
